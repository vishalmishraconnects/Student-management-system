#!/usr/bin/env bash

set -e
set -x

poetry run pytest tests/e2e