class TestMain:
    def test_main(self):
        assert True
