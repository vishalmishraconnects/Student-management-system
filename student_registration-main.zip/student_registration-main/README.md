1. pip install poetry
2. poetry install 
2. poetry shell
3. execute main.py